package team.stray.bridgechat.bridge;

public interface Direction {
	
	public static final int EAST 		= 4;
	public static final int NORTH 		= 3;
	public static final int WEST 		= 2;
	public static final int SOUTH 		= 1;
}
