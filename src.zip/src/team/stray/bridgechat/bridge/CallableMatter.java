package team.stray.bridgechat.bridge;

public interface CallableMatter {

	public static final int NOTRUMP		= 5;
	public static final int SPADES 		= 4;
	public static final int HEARTS		= 3;
	public static final int DIAMONDS	= 2;
	public static final int CLUBS 		= 1;
	public static final int PASS 		= 0;
}
