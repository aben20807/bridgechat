package team.stray.bridgechat.bridge;

public interface Suit {

	public static final int SPADES 		= 4;
	public static final int HEARTS 		= 3;
	public static final int DIAMONDS 	= 2;
	public static final int CLUBS 		= 1;
}
