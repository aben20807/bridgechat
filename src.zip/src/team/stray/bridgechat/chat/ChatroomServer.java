package team.stray.bridgechat.chat;

public class ChatroomServer{
	
	public ChatroomServer(){
		
	}
}